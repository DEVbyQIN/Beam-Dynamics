"""Document-only QA: hashes, excerpts, citations, links and example geometry."""
from pathlib import Path
import json,hashlib,re,sys
from pypdf import PdfReader
B=Path(__file__).resolve().parent;R=B.parents[1];OLD=R/'docs/project_manual_20261026'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
errors=[];out=[]
protection=load(B/'protected_before.json')
changed={kind:[name for name,h in items.items() if not (R/name).is_file() or sha(R/name)!=h] for kind,items in protection.items()}
if any(changed.values()):errors.append('Protected source or legacy archive changed')
for key in ['manual','technical']:
 folder=B/key;pdf=next(folder.glob('UED*.pdf'));reader=PdfReader(pdf);text='\n'.join(p.extract_text() or '' for p in reader.pages)
 log=(folder/'build/main.log').read_text(errors='replace')
 diagnostics=[s for s in ['Overfull','Missing character:','Reference .* undefined','Citation .* undefined','LaTeX Error'] if re.search(s,log)]
 if diagnostics:errors.append(key+' diagnostics: '+str(diagnostics))
 if '??' in text:errors.append(key+' unresolved placeholders')
 if not all(s in text for s in ['UED','RF','OCELOT','Windows']):errors.append(key+' incomplete searchable text')
 refs=len(re.findall(r'\\bibitem\{',(folder/('content.tex' if key=='manual' else 'references.tex')).read_text()))
 links=0;outside=[]
 for i,page in enumerate(reader.pages,1):
  for annot in page.get('/Annots',[]):
   a=annot.get_object();links+=a.get('/Subtype')=='/Link';rect=a.get('/Rect')
   if rect and (float(rect[0])<-.1 or float(rect[1])<-.1 or float(rect[2])>float(page.mediabox.width)+.1 or float(rect[3])>float(page.mediabox.height)+.1):outside.append(i)
 if outside:errors.append(key+' annotations outside page')
 out.append({'document':key,'pages':len(reader.pages),'sha256':sha(pdf),'references':refs,'internal_and_external_links':links,'out_of_page_annotations':outside,'latex_diagnostics':diagnostics})
source=load(B/'technical/source_manifest.json');bad=[]
for row in source:
 p=B/'technical/source_snapshot'/row['path']
 if sha(p)!=row['sha256'] or p.read_bytes()!=(OLD/'source_snapshot'/row['path']).read_bytes():bad.append(row['path'])
if bad:errors.append('Frozen source copy mismatch')
excerpts=load(B/'technical/code_excerpts.json')
for row in excerpts:
 src=(B/'technical/source_snapshot'/row['path']).read_text().splitlines()
 expected='\n'.join(src[row['start']-1:row['end']])+'\n'
 if expected!=(B/'technical/snippets'/f"{row['id']}.txt").read_text():errors.append('Excerpt mismatch: '+row['id'])
evidence=load(B/'technical/evidence_manifest.json')
for row in evidence:
 if not row['available'] or sha(B/'technical'/row['local'])!=row['sha256']:errors.append('Historical evidence mismatch: '+row['id'])
new=load(B/'technical/new_evidence_manifest.json')
for row in new:
 if sha(B/'technical'/row['local'])!=row['sha256']:errors.append('New metadata mismatch')
screens=load(B/'manual/screenshot_sources.json')
for row in screens['files']:
 if sha(B/'manual/figures'/row['path'])!=row['sha256']:errors.append('Screenshot mismatch: '+row['path'])
# Independent check of the instructional relocation example; no driver imports.
sys.path.insert(0,str(R))
from shared.params import load_config
from shared.geometry import validate_geometry
cfg=load_config();els={e['name']:e for e in cfg['lattice']['elements']}
els['drift2']['length']=.250;els['rf1']['z_start']=.410;els['drift3'].update(z_start=.432,length=.345)
g=validate_geometry(cfg)
if abs(g['sample_m']-.777)>1e-12:errors.append('GUI relocation example sample mismatch')
result={'date':'2026-10-27','documents':out,'protected_production_files':len(protection['production']),'protected_legacy_files':len(protection['legacy']),'protected_changes':changed,'frozen_source_files':len(source),'frozen_source_match':not bad,'exact_code_excerpts':len(excerpts),'historical_evidence_files':len(evidence),'new_metadata_files':len(new),'screenshot_hashes_checked':len(screens['files']),'gui_relocation_example_sample_m':g['sample_m'],'new_simulation_calls':0,'production_source_edits':0,'errors':errors,'scope':'Document/source preservation and geometry example checks; no new physical or Windows qualification.'}
(B/'quality_check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
if errors:raise SystemExit(1)
