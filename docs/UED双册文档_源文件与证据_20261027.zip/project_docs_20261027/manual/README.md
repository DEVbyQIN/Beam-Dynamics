# UED 项目说明书

本目录主文件为 `main.tex`。重编译说明见上一级 README；GUI 截图和技术记录均保留来源。
