# UED 双册文档（2026-10-27，v2.0）

- `manual/UED项目说明书_20261027.pdf`：日常阅读。比仓库 README 更完整，讲物理、架构、参数、GUI 和结果边界，引用 6 条主要文献。
- `technical/UED技术参考与审计附件_20261027.pdf`：按需查证。保存详细方程、算法、历史证据/预算、Windows 失败模式、完整文献、代码摘录和冻结源码。

旧 `../project_manual_20261026/` 和旧 ZIP 不覆盖。新版不代表新增物理认证，不含新模拟。2026-10-26 发布记录确认 78a9682；本次文档尚未提交/推送。

## 重编译

需 XeLaTeX/latexmk/ctex/Fandol 与 Python pypdf。在本目录运行 `python build_all.py`。脚本分别编译两个项目，再为缺失映射的 Fandol 字体附加 Adobe-GB1 Unicode 映射；不改变页面内容。`manual/` 和 `technical/` 各自以 `main.tex` 为主文件，可独立打开。

`content_map.json` 列出分工；`protected_before.json` 保留旧文档/科学代码的前态哈希；`quality_check.json` 与 `visual_review.json` 记录实际检查。技术附件的 source_manifest/evidence_manifest 沿用旧快照，E12 新来源另存。大粒子云和原报告部分图仍在原研究目录；附件不是完整环境发行包。

最终篇幅：说明书 **9 页**，技术参考与审计附件 **20 页**。已完成逐页渲染检查、文献/代码摘录/历史证据哈希与几何例子核对。`check_documents.py` 用于原仓库内的保全检查；仅重编译文档时无需运行该脚本。
