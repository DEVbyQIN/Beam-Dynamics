"""Compile the two documentary projects. No driver or simulator imports."""
from pathlib import Path
import json,subprocess,hashlib
from pypdf import PdfReader,PdfWriter
from pypdf.generic import NameObject,DecodedStreamObject
ROOT=Path(__file__).resolve().parent
OUTPUTS={'manual':'UED项目说明书_20261027.pdf','technical':'UED技术参考与审计附件_20261027.pdf'}
results=[]
for name,filename in OUTPUTS.items():
 folder=ROOT/name
 with (folder/'compile.log').open('w') as log:
  subprocess.run(['latexmk','-xelatex','-interaction=nonstopmode','-halt-on-error','-outdir=build','main.tex'],cwd=folder,stdout=log,stderr=subprocess.STDOUT,check=True)
 reader=PdfReader(folder/'build/main.pdf');writer=PdfWriter();writer.clone_document_from_reader(reader)
 stream=DecodedStreamObject();stream.set_data((folder/'fonts/Adobe-GB1-UCS2').read_bytes())
 mapping=writer._add_object(stream.flate_encode());fixed=[]
 for page in writer.pages:
  for value in page['/Resources'].get('/Font',{}).values():
   font=value.get_object()
   if 'Fandol' in str(font.get('/BaseFont')) and '/ToUnicode' not in font:
    font[NameObject('/ToUnicode')]=mapping;fixed.append(str(font['/BaseFont']))
 out=folder/filename;writer.write(out)
 reopened=PdfReader(out);assert 'UED' in reopened.pages[0].extract_text()
 row={'project':name,'pdf':str(out.relative_to(ROOT)),'pages':len(reopened.pages),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'unicode_maps_added':fixed}
 results.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
(ROOT/'build_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
